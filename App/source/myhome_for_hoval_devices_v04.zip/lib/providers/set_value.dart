import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'package:flutter_settings_screens/flutter_settings_screens.dart';

class SetValueProvider extends ChangeNotifier {
  String state = "init";
  void resetState() {
    state="init";
  }

  Future<void> setValue(int index, String strValue) async {
    final url ='http://'+Settings.getValue<String>('key-ip-address-cgw','192.168.0.0')+'/setparam?num=${index+1}';
    try {
      state="wait";
      notifyListeners();
      var response = await http.post(Uri.parse(url), body: strValue);
      if(response.body=="OK") {
        state="set";
      } else {
        state="retry";
      }
      notifyListeners();
      return Future.value();
    } catch (e) {
      print(e);
      return Future.error('An error occured');
    }
  }
}