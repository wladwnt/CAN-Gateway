import 'package:flutter/material.dart';
import 'package:flutter_settings_screens/flutter_settings_screens.dart';
import 'package:myhome_for_hoval_devices/providers/parameters.dart';
import 'package:provider/provider.dart';
import 'package:myhome_for_hoval_devices/providers/devices.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final RegExp _ipRegex = RegExp(
      r"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
  @override
  Widget build(BuildContext context) {
    final devicesProvider = Provider.of<DevicesProvider>(context);
    final parametersProvider = Provider.of<ParametersProvider>(context);
    return Container(
        key: UniqueKey(),
        child: Column(
            children: <Widget> [
              TextInputSettingsTile(
                  title: AppLocalizations.of(context)!.setIPGateway,
                  settingKey: 'key-ip-address-cgw',
                  initialValue: '192.168.0.0',
                  borderColor: Colors.blueAccent,
                  errorColor: Colors.deepOrangeAccent,
                  validator: (text) => _ipRegex.hasMatch(text==null?'':text)?null:AppLocalizations.of(context)!.setPleaseEnterIP,
                  onChange: (text) {
                    Settings.setValue<String>('key-ip-address-cgw', text);
                    parametersProvider.fetchParameters();
                  }
              ),
            Divider(),
                  Padding(
                      padding: const EdgeInsets.only(
                        left: 12,
                        right: 12,
                        top: 0,
                        bottom: 0,
                      ),
                      child: Row(
                      children: <Widget>[
                        Expanded(child:Text(AppLocalizations.of(context)!.setListCGW)),
                        ElevatedButton(
                          style: TextButton.styleFrom(textStyle: const TextStyle(fontSize: 14),),
                          onPressed: devicesProvider.refresh,
                          child: Text(AppLocalizations.of(context)!.setSearchAgain),
                        ),
                      ]
                    ),
                  ),
                  _buildDevList(context),
                  Divider(),
              SwitchSettingsTile(
                settingKey: 'enable-intro',
                title: AppLocalizations.of(context)!.setEnableIntro,
                enabledLabel: AppLocalizations.of(context)!.enabledLabel,
                disabledLabel: AppLocalizations.of(context)!.disabledLabel,
                onChange: (value) {
                  Settings.setValue<bool>('enable-intro', value);
                },
              ),
            ]
        ),
    );
  }

  Widget _buildDevList(context) {
    final devicesProvider = Provider.of<DevicesProvider>(context);
    final parametersProvider = Provider.of<ParametersProvider>(context);
    return devicesProvider.length != 0
        ? RefreshIndicator(
      child:
          ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              padding: EdgeInsets.all(4),
              itemCount: devicesProvider.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        leading: Icon(Icons.forward),
                        title: Text(AppLocalizations.of(context)!.deviceCGW),
                        subtitle: Text("IP: "+devicesProvider.devices[index]),
                        trailing: ElevatedButton(
                          style: TextButton.styleFrom(
                            textStyle: const TextStyle(fontSize: 14),
                          ),
                          onPressed: () async {
                            await Settings.setValue<String>('key-ip-address-cgw', devicesProvider.devices[index]);
                            setState(() {});
                            parametersProvider.fetchParameters();
                            },
                          child: Text(AppLocalizations.of(context)!.useThis),
                        ),
                      )
                    ],
                  ),
                );
              }),
      onRefresh: devicesProvider.refresh,
    )
        : Center(child: Text(devicesProvider.searchState=="dosearch"?AppLocalizations.of(context)!.searchDoSearch:(devicesProvider.searchState=="nofound"?AppLocalizations.of(context)!.searchNoFound:AppLocalizations.of(context)!.searchFound)));
  }
}