import 'package:flutter/material.dart';
import 'dart:async';
import "package:upnp/upnp.dart";

class DevicesProvider extends ChangeNotifier {
  int length = 0;
  List<String> _devices = [];
  String searchState = "";

  DevicesProvider(){
    refresh();
  }

  Future<void> fetchDevices() async {
    var disc = new DeviceDiscoverer();
    await disc.start(ipv6: false);
    disc.quickDiscoverClients().listen((client) async {
      try {
        var dev = await client.getDevice();
        if(dev!.modelName=="CANGateway") {
        //if(dev!=null) {
          _devices.add(Uri.parse(dev.url.toString()).host.toString());
          print("!!!!!!!!!!!!  DEV added ${Uri.parse(dev.url.toString()).host.toString()}");
          length = _devices.length;
          searchState='Found!';
          notifyListeners();
        }
      } catch (e, stack) {
        print("ERROR: ${e} - ${client.location}");
        print(stack);
      }
    });
  }

  Future<void> refresh() async {
    _devices.clear();
    length=0;
    searchState='Search for CAN Gateways in your local network ...';
    notifyListeners();
    await fetchDevices();
    await Future.delayed(Duration(seconds: 5));
    if(length==0) {
      searchState='No CAN Gateway devices found.';
      notifyListeners();
    }
  }

  List<String> get devices => [..._devices];
}