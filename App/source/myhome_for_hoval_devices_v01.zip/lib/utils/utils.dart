List<String> GetParamList(int devType, int funcGroup, int funcNum, int paramID) {
  if(devType==8 && funcGroup==50 && funcNum==0 && paramID==39652)
    return ["Off", "Normal", "VOC", "Humidity", "Frost", "CoolVent", "Fault"];
  if(devType==8 && funcGroup==50 && funcNum==0 && paramID==39600)
    return ["Off", "On"];
  if(devType==4 && funcGroup==2 && funcNum==0 && paramID==1066)
    return ["Off", "On"];
  if(devType==8 && funcGroup==50 && funcNum==0 && paramID==40650)
    return ["Standby", "Week 1", "Week 2", "", "Constant", "Eco"];
  if((devType==0 || devType==3 || devType==4) && funcGroup==1 && funcNum<=4 && paramID==3050)
    return ["Standby", "Week 1", "Week 2", "", "Constant", "Eco", "Manual heating", "Manual cooling"];
  if((devType==0 || devType==3 || devType==4) && funcGroup==2 && funcNum<=4 && paramID==5050)
    return ["Standby", "Week 1", "Week 2", "", "Constant", "Eco"];
  if(devType==0 && funcGroup==10 && funcNum<=1 && paramID==9075)
    return ["Off", "Auto", "", "", "Heating", "Cooling"];
  if(devType==3 && funcGroup==0 && funcNum==0 && paramID==21044)
    return ["Off", "FE=1", "FE=2", "FE=3", "FE=4", "FE=5"];
  if(devType==0 && funcGroup==10 && funcNum==0 && paramID==2053)
    return ["Off", "Heating", "PreHeating", "Externally Off", "Cooling", "PreCooling", "", "", "", "", "", "", "", "", "",
    "Alarm", "Error", "Blocked", "", "", "", "WFmax Off", "WFsoll Off", "", "", "", "Bivalent Off", "Warm water closed",
    "Min Off", "Min On", "Heating Up", "Ausbrand", "Nachlauf", "Verz. Folge WE", "Overtemperature"];
  if(devType==3 && funcGroup==1 && funcNum<=4 && paramID==2051)
    return ["Off", "Normal", "Compfort", "Eco", "Frost", "Zwangsabnahme", "Zwangsdrosselung", "Ferienbetrieb", "Party",
    "Normal cooling", "Comfort cooling", "Eco cooling", "Error", "Manual", "Safe Cooling", "Party cooling", "Austrocknung Heat Up",
    "Austrocknung normal", "Austrocknung cool down", "Austrocknung end", "", "",
      "Cooling external/constant", "Heating external/constant", "", "", "Smart Grid"];
  if(devType==3 && funcGroup==2 && funcNum<=4 && paramID==2052)
    return ["Off", "Normal", "Comfort", "Zwangsdrosselung", "Zwangsladung", "Error", "WW Entnahme", "Warning",
      "Reduced ALdebetrieb", "", "", "", "Vorzugsbetrieb SmartGrid", "Abnahmezwang SmartGrid"];
  if(devType==3 && funcGroup==0 && funcNum==0 && paramID==23084)
    return ["Off", "On"];
  if(devType==3 && funcGroup==0 && funcNum==0 && (paramID>=23031 && paramID<=21039))
    return ["Off", "On"];
  if(devType==3 && funcGroup==0 && funcNum==0 && (paramID>=23045 && paramID<=21047))
    return ["Off", "On"];
  return [];
}

bool ParamHasList(int devType, int funcGroup, int funcNum, int paramID) {
  if ((devType==8 && funcGroup==50 && funcNum==0 && paramID==39652)
      || (devType==8 && funcGroup==50 && funcNum==0 && paramID==40650))
    return true;
  return false;
}

List<String> GetParamNonEmptyList(int devType, int funcGroup, int funcNum, int paramID) {
  List<String> _list= GetParamList(devType, funcGroup, funcNum, paramID);
  List<String> _list1=[];
  for(int i=0;i<_list.length;i++) if(_list[i]!="") _list1.add(_list[i]);
  return _list1;
}

List<int> GetParamNonEmptyListIndexes(int devType, int funcGroup, int funcNum, int paramID) {
  List<String> _list= GetParamList(devType, funcGroup, funcNum, paramID);
  List<int> _list1=[];
  for(int i=0;i<_list.length;i++) if(_list[i]!="") _list1.add(i);
  return _list1;
}

String ValueToDecodedValue(String value, int devType, int funcGroup, int funcNum, int paramID) {
  if (ParamHasList(devType, funcGroup, funcNum, paramID)){
    List<String> _list= GetParamList(devType, funcGroup, funcNum, paramID);
    try {
      int _intValue = double.parse(value).toInt();
      if (_intValue < _list.length && _intValue >= 0) {
        return _list[_intValue];
      } else {
        return value;
      }
    } catch (e) {
      return value;
    }
  }
  return value;
}