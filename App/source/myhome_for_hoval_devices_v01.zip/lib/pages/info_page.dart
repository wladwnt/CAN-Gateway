import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class InfoPage extends StatelessWidget {
  static const TextStyle optionStyle =
  TextStyle(fontSize: 24, fontWeight: FontWeight.bold);

  @override
  Widget build(BuildContext context) {
    return Container(
      key: UniqueKey(),
      child: Column(
        children: [
          SizedBox(height: 8,),
          Center(child: Text('My Home App', style: optionStyle,textAlign: TextAlign.center,)),
          SizedBox(height: 8,),
          Center(child: Text('for Hoval devices', style: optionStyle,textAlign: TextAlign.center,)),
          SizedBox(height: 16,),
          FractionallySizedBox(
            alignment: Alignment.topCenter,
            widthFactor: 0.25,
            child: Image(image: AssetImage('assets/icon/icon.png')),
          ),
          SizedBox(height: 16,),
          InkWell(
              child: Text('Get more Info on GitHub', style: TextStyle(color:Colors.blueAccent, fontSize: 20, fontWeight: FontWeight.bold, decoration: TextDecoration.underline,)),
              onTap: () => launch('https://github.com/wladwnt/CAN-Gateway')
          ),
          SizedBox(height: 16,),
          Center(child: Text('You will need a special hardware (CAN Gateway) to get the information from / to control you Hoval devices. Please read carefully the information on GitHub. Example:', style: TextStyle(fontSize: 14),textAlign: TextAlign.center,)),
          SizedBox(height: 16,),
          Image(image: AssetImage('assets/image/system.jpg')),
          SizedBox(height: 16,),
          Center(child: Text('This software as well as the CAN Gateway are not produced/developed/approved by Hoval A.G., but compatible with some products from Hoval.', style: TextStyle(fontSize: 14),textAlign: TextAlign.center,)),
          SizedBox(height: 16,),
          Center(child: Text('(c) W. Waag, 2021, cangateway@gmx.de', style: TextStyle(fontSize: 14),textAlign: TextAlign.center,)),
        ]
      ),
    );
  }
}