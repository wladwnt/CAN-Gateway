import 'package:flutter/material.dart';
import 'package:flutter_settings_screens/flutter_settings_screens.dart';
import 'package:myhome_for_hoval_devices/providers/parameters.dart';
import 'package:provider/provider.dart';
import 'package:myhome_for_hoval_devices/providers/devices.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final RegExp _ipRegex = RegExp(
      r"^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$");
  @override
  Widget build(BuildContext context) {
    final devicesProvider = Provider.of<DevicesProvider>(context);
    final parametersProvider = Provider.of<ParametersProvider>(context);
    return Container(
        key: UniqueKey(),
        child: Column(
            children: <Widget> [
              TextInputSettingsTile(
                  title: 'IP Address of CAN Gateway',
                  settingKey: 'key-ip-address-cgw',
                  initialValue: '192.168.20.9',
                  borderColor: Colors.blueAccent,
                  errorColor: Colors.deepOrangeAccent,
                  validator: (text) => _ipRegex.hasMatch(text==null?'':text)?null:'Please enter correct IPv4 address!',
                  onChange: (text) {
                    Settings.setValue<String>('key-ip-address-cgw', text);
                    parametersProvider.fetchParameters();
                  }
              ),
            Divider(),
                  Padding(
                      padding: const EdgeInsets.only(
                        left: 12,
                        right: 12,
                        top: 0,
                        bottom: 0,
                      ),
                      child: Row(
                      children: <Widget>[
                        Expanded(child:Text("List of CAN Gateways:")),
                        ElevatedButton(
                          style: TextButton.styleFrom(textStyle: const TextStyle(fontSize: 14),),
                          onPressed: devicesProvider.refresh,
                          child: const Text('Search again'),
                        ),
                      ]
                    ),
                  ),
                  _buildDevList(context),
                  Divider(),
            ]
        ),
    );
  }

  Widget _buildDevList(context) {
    final devicesProvider = Provider.of<DevicesProvider>(context);
    final parametersProvider = Provider.of<ParametersProvider>(context);
    return devicesProvider.length != 0
        ? RefreshIndicator(
      child:
          ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              padding: EdgeInsets.all(4),
              itemCount: devicesProvider.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        leading: Icon(Icons.forward),
                        title: Text("CAN Gateway device"),
                        subtitle: Text("IP: "+devicesProvider.devices[index]),
                        trailing: ElevatedButton(
                          style: TextButton.styleFrom(
                            textStyle: const TextStyle(fontSize: 14),
                          ),
                          onPressed: () async {
                            await Settings.setValue<String>('key-ip-address-cgw', devicesProvider.devices[index]);
                            setState(() {});
                            parametersProvider.fetchParameters();
                            },
                          child: const Text('Use this'),
                        ),
                      )
                    ],
                  ),
                );
              }),
      onRefresh: devicesProvider.refresh,
    )
        : Center(child: Text(devicesProvider.searchState));
  }
}